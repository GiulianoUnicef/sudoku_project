#include "homepage.h"
#include <stdio.h>

int main() 
{
  avviareMenuPrincipale();
  getchar();
  return 0;
}