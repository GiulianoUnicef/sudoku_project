#ifndef IMPOSTAZIONI_H 
#define IMPOSTAZIONI_H

#include "funzioni_utilita.h"

void avviareMenuDifficolta();
int collezionareDifficolta(int *inputDifficolta);
int collezionareDimensione(int *inputDimensione);
void stampareMenuDifficolta();
void stampareTitoloImpostazioni();
void stampareMenuImpostazioni();

void collezionareNomePartita(char *dest);

#endif
