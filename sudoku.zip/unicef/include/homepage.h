#ifndef HOMEPAGE_H 
#define HOMEPAGE_H

#include "funzioni_utilita.h"

void collezionareInputHomepage(int *input); /* recupera un input da terminale inserito dall'utente */
void stampareMenuPrincipale();
void avviareMenuPrincipale();

#endif
